#ifndef __SAPIUMTYPES_H__
#define __SAPIUMTYPES_H__

#include "SAPIUMConsts.h"
#include "SAPIUMEnums.h"

/*
 * Windows like type definitions
 */
#ifndef DONT_OVERLOAD_TYPE_DEFINITIONS
#define DONT_OVERLOAD_TYPE_DEFINITIONS
#include "wintypes.h"
#endif

typedef void (SAPI_WINAPI *SAPI_UM_CALC_CREDENTIALS_CALLBACK)(
											unsigned char	*Password,
											unsigned long	PasswordLen,
											unsigned char	*CalcCredential,
											unsigned long	*CalcCredentialLen,
											unsigned char	*ExtraCredential,
											unsigned long	*ExtraCredentialLen);


typedef void			*SAPI_UM_SES_HANDLE;
typedef unsigned char	SAPI_UM_CONTEXT[UM_OPAQUE_CONTEXT_LENGTH];
typedef void			*SAPI_UM_USR_HANDLE;

typedef char			SAPI_UM_GUID[SAPIUM_GUID_LENGTH];


typedef struct {
	unsigned long	MajorVersion;
	unsigned long	MinorVersion;
}SAPI_UM_INFO_STRUCT, *PSAPI_UM_INFO_STRUCT;

// allows filtering and sorting of results. note that only one order parameter can be used.
typedef struct {
	SAPI_LPCWSTR			UserLoginName;					// if not NULL, order results by name starting from the given value
	SAPI_LPCWSTR			UserCN;							// if not NULL, order results by CN starting from the given value
	SAPI_LPCWSTR			EmailAddress;					// if not NULL, order results by mail starting from the given value
	unsigned long			UpdateTime;						// if not -1, order results by update time starting from the given value
	SAPI_UM_ENUM_USER_ENROLLMENT_STATUS EnrollmentStatus;	// if not -1 filter results where enrollment status matches
	long					RightsMask;						// if not -1 filter results where rights mask matches
	int						OrderDescending;				// if 1 order desc, if 0 order ascending
}SAPI_UM_USERS_EXTENDED_FILTER_STRUCT;

typedef struct {
	SAPI_UM_ENUM_USER_TYPE				 UserType;
	SAPI_UM_USERS_EXTENDED_FILTER_STRUCT *ExtendedFilter;
}SAPI_UM_USERS_FILTER_STRUCT;


#endif