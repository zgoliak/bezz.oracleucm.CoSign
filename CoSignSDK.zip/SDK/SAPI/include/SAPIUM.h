#ifndef __SAPIUM_H__
#define __SAPIUM_H__

#include "SAPIUMTypes.h"
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the CSNOBAPI_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// SAPIUM functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef SAPIUM_EXPORTS
#define SAPIUM __declspec(dllexport)
//#elif SAPI_INTERNAL
#else
 #ifndef SAPIUM
 #define SAPIUM
 #endif
//#else
//#define SAPIUM __declspec(dllimport)
#endif
#ifdef  __cplusplus
extern  "C" {
#endif

SAPIUM int SAPIUMInit();

SAPIUM int SAPIUMLibInfoGet(
					PSAPI_UM_INFO_STRUCT	SAPIUMInfoStruct);

SAPIUM int SAPIUMExtendedLastErrorGet();

SAPIUM int SAPIUMHandleAcquire(
	                SAPI_UM_SES_HANDLE	*Handle);

SAPIUM int SAPIUMLogon(
	                SAPI_UM_SES_HANDLE	Handle,
	                SAPI_LPCWSTR		UserLoginName,
					SAPI_LPCWSTR		DomainName,
	                unsigned char		*Password,
	                long				PasswordLen);

SAPIUM int SAPIUMLogonBuiltIn(
	                SAPI_UM_SES_HANDLE	Handle,
	                SAPI_LPCWSTR		UserLoginName,
	                unsigned char		*Password,
	                long				PasswordLen);

SAPIUM int SAPIUMUserAdd(
	                SAPI_UM_SES_HANDLE					Handle,
	                SAPI_LPCWSTR						UserLoginName,
	                SAPI_LPCWSTR						UserCN,
	                SAPI_LPCWSTR						emailAddress,
	                unsigned char						*Password,
	                unsigned long						PasswordLen,
					SAPI_UM_CALC_CREDENTIALS_CALLBACK	CalcCredentialFunc,
	                unsigned long						flags); // user rights

SAPIUM int SAPIUMUserUpdate(
	                SAPI_UM_SES_HANDLE	Handle,
	                SAPI_LPCWSTR		UserLoginName,
	                SAPI_LPCWSTR		UserCN,
	                SAPI_LPCWSTR		emailAddress,
	                unsigned long		flags); // user rights

SAPIUM int SAPIUMCredentialSet(
	                SAPI_UM_SES_HANDLE					Handle,
	                SAPI_LPCWSTR						UserLoginName,
	                unsigned char						*Password,
	                unsigned long						PasswordLen,
					SAPI_UM_CALC_CREDENTIALS_CALLBACK	CalcCredentialFunc);

SAPIUM int SAPIUMUserDelete(
	                SAPI_UM_SES_HANDLE	Handle,
	                SAPI_LPCWSTR		UserLoginName);

SAPIUM int SAPIUMUsersSyncBegin(
	                SAPI_UM_SES_HANDLE	Handle,
                    SAPI_UM_CONTEXT		SyncContext);

SAPIUM int SAPIUMUserSync(
	                SAPI_UM_SES_HANDLE					Handle,
	                SAPI_LPCWSTR						UserLoginName,
	                SAPI_LPCWSTR						UserCN,
	                SAPI_LPCWSTR						emailAddress,
	                unsigned char						*Password,
	                unsigned long						PasswordLen,
					SAPI_UM_CALC_CREDENTIALS_CALLBACK	CalcCredentialFunc,
	                unsigned long						flags); // user rights

SAPIUM int SAPIUMUsersSyncEnd(
	                SAPI_UM_SES_HANDLE	Handle,
                    SAPI_UM_CONTEXT		SyncContext);

SAPIUM int SAPIUMUsersSyncStop(
	                SAPI_UM_SES_HANDLE	Handle,
                    SAPI_UM_CONTEXT		SyncContext);

SAPIUM int SAPIUMUsersEnumInit(
	                SAPI_UM_SES_HANDLE			Handle,
					SAPI_UM_CONTEXT				UsersEnumContext,
					SAPI_UM_USERS_FILTER_STRUCT	*UsersFilterStruct);

SAPIUM int SAPIUMUsersEnumCont(
	                SAPI_UM_SES_HANDLE	Handle,
					SAPI_UM_CONTEXT		UsersEnumContext,
					SAPI_UM_USR_HANDLE	*UserHandle); 

SAPIUM int SAPIUMUserInfoGet(
	                SAPI_UM_SES_HANDLE		Handle,
					SAPI_UM_USR_HANDLE		UserHandle, 
	                SAPI_LPWSTR				UserLoginName,
	                long					*UserLoginNameLen,
	                SAPI_LPWSTR				UserCN,
	                long					*UserCNLen,
	                SAPI_LPWSTR				EmailAddress,
	                long					*EmailAddressLen,
					SAPI_UM_ENUM_USER_TYPE	*Kind,
					long					*RightsMask,
					unsigned long			*UpdateTime,
					SAPI_UM_GUID			Guid
					);

SAPIUM int SAPIUMUserInfoGetEx(
	                SAPI_UM_SES_HANDLE							Handle,
					SAPI_UM_USR_HANDLE							UserHandle, 
	                SAPI_LPWSTR									UserLoginName,
	                long										*UserLoginNameLen,
	                SAPI_LPWSTR									UserCN,
	                long										*UserCNLen,
	                SAPI_LPWSTR									EmailAddress,
	                long										*EmailAddressLen,
					SAPI_UM_ENUM_USER_TYPE						*Kind,
					long										*RightsMask,
					unsigned long								*UpdateTime,
					SAPI_UM_GUID								Guid,
					SAPI_UM_ENUM_USER_ENROLLMENT_STATUS			*EnrollmentStatus,
					SAPI_UM_ENUM_USER_ENROLLMENT_REASON			*EnrollmentReason,
					SAPI_UM_ENUM_USER_LOGIN_STATUS				*LoginStatus,
					long										*Counter1,
					long										*Counter2,
					long										*Counter3,
                    SAPI_UM_ENUM_USER_CERT_STATUS_TYPE			*UserCertStatus,
                    SAPI_UM_ENUM_PENDING_REQUEST_STATUS_TYPE	*CertRequestStatus					
					);

SAPIUM int SAPIUMCounterReset(
	                SAPI_UM_SES_HANDLE			Handle,
	                SAPI_LPCWSTR				UserLoginName,
					SAPI_UM_ENUM_COUNTER_TYPE	CounterToReset);

SAPIUM int SAPIUMUserGetByLoginName(
	                SAPI_UM_SES_HANDLE		Handle,
	                SAPI_LPCWSTR			UserLoginName,
					SAPI_UM_USR_HANDLE		*UserHandle);

SAPIUM int SAPIUMSCPSet(
	                char *Address);

SAPIUM int SAPIUMLogoff(
	                SAPI_UM_SES_HANDLE	Handle);

SAPIUM void SAPIUMHandleRelease (void *Handle);

SAPIUM int SAPIUMFinalize();

#ifdef  __cplusplus
}
#endif

#endif