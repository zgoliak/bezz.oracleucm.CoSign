$(function () {
	$("body").css("background-image", "none");
	$("body").css("background-color", "#F7F8F8");
	if (top === self)
	{
		var newDiv = $("<div id='openTextHeader'><a href='/otcs/cs.exe?func=Enterprise.Home'></a></span><span></span></div>");
		$("body").prepend(newDiv);
		$(".logo").hide();
	}
});