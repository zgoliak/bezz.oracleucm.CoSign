﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;

namespace testApp
{
    public partial class _Default : System.Web.UI.Page
    {
        private const string SUCCESS = "0";
        private string SERVER_PATH = "http://localhost:54015/UploadDoc.aspx";
        //private const string SERVER_PATH = "http://212.25.124.10/WSCtest/UploadDoc.aspx";
        //private const string SERVER_PATH = "http://localhost:58886/VerifyService.aspx";
        private const string DEMO_FILE = "demo.pdf";

        Random randomNum;

        protected void Page_Load(object sender, EventArgs e)
        {
            SERVER_PATH = ConfigurationSettings.AppSettings["serverPath"];
            randomNum = new Random();
            if (Session["cookies"] == null)
            {
                Session["cookies"] = new CookieContainer();
            }

            StatusLabel.Text = "";
            resultBox.Visible = false;
            if (Session["id"] == null || string.IsNullOrEmpty(Session["id"].ToString()))
            {
                xmlButton.Enabled = false;
            }

            if (!string.IsNullOrEmpty(Request.QueryString["docId"]))
            {
                try
                {
                    // in case this page also serves as FileUploadURL
                    if (Request.ContentType == "application/pdf")
                    {
                        FileStream fileStream = new FileStream(Server.MapPath("~/" + Request.QueryString["docId"] + ".pdf"), FileMode.Create, FileAccess.Write);
                        CopyStream(Request.InputStream, fileStream);
                        fileStream.Close();
                    }
                    else // In case this page also serves as FinishURL
                    {
                        linkToDoc.HRef = Request.QueryString["docId"] + ".pdf";
                        linkToDoc.Visible = true;
                    }
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
        }

        protected void radioButton_Change(object sender, EventArgs e)
        {
            if ((sender as RadioButton).Checked)
            {
                StreamReader streamReader = new StreamReader(Server.MapPath("~/" + getXmlFileName(sender as RadioButton) + ".xml"));
                string xmlContent = streamReader.ReadToEnd();
                streamReader.Close();

                xmlTextInput.Text = xmlContent;
            }
        }

        public string PostXML(string i_Url, string i_Content)
        {
            return PostRequest(i_Url, i_Content, "application/x-www-form-urlencoded", false);
        }

        public string PostFile(string i_Url, string i_FilePath)
        {
            return PostRequest(i_Url, i_FilePath, "application/pdf", true);
        }

        private string PostRequest(string i_Url, string i_Content, string i_ContentType, bool i_IsFile)
        {
            HttpWebRequest WebReq = (HttpWebRequest)WebRequest.Create(i_Url);
            WebReq.Method = "POST";
            WebReq.ContentType = i_ContentType;
            WebReq.CookieContainer = (CookieContainer)Session["cookies"]; //Cookies must be sent
            Stream PostData = null;

            if (i_IsFile)
            {
                using (FileStream fileStream = File.OpenRead(i_Content))
                {
                    WebReq.ContentLength = fileStream.Length;
                    PostData = WebReq.GetRequestStream();
                    CopyStream(fileStream, PostData);
                }
            }
            else
            {
                byte[] buffer = Encoding.UTF8.GetBytes(i_Content);
                WebReq.ContentLength = buffer.Length;
                PostData = WebReq.GetRequestStream();
                PostData.Write(buffer, 0, buffer.Length);
            }

            PostData.Close();

            HttpWebResponse WebResp = (HttpWebResponse)WebReq.GetResponse();
            Stream Answer = WebResp.GetResponseStream();
            StreamReader _Answer = new StreamReader(Answer);
            string data = _Answer.ReadToEnd();
            _Answer.Close();
            WebResp.Close();
            return data;
        }

        public string uploadFileRequest(string url, string i_FileName)
        {
            string retVal = null;

            fileUploadControl.SaveAs(Server.MapPath("~/") + i_FileName);

            retVal = PostFile(url, Server.MapPath("~/") + i_FileName);

            if (File.Exists(Server.MapPath("~/") + i_FileName))
            {
                File.Delete(Server.MapPath("~/") + i_FileName);
            }

            return retVal;
        }

        protected void UploadButton_Click(object sender, EventArgs e)
        {
            wscIFrame.Attributes["src"] = "";
            bool useDemoFile = false;

            if (!fileUploadControl.HasFile)
            {
                useDemoFile = true;
            }

            try
            {
                if (useDemoFile || fileUploadControl.PostedFile.ContentType == "application/pdf")
                {
                    int randomID = randomNum.Next(10000, 100000);
                    String response;
                    if (useDemoFile)
                    {
                        response = PostFile(SERVER_PATH + "?id=" + randomID, Server.MapPath("~/") + DEMO_FILE);
                    }
                    else
                    {
                        response = uploadFileRequest(SERVER_PATH + "?id=" + randomID, fileUploadControl.FileName);
                    }
                    resultBox.Visible = true;
                    result.InnerHtml = "<xmp>" + response.Trim() + "</xmp>";
                    string returnCode = Regex.Match(response, @"(?si)<returnCode>([^<>]*)</returnCode>").Groups[1].Value;
                    if (returnCode == SUCCESS)
                    {
                        Session["id"] = randomID;
                        xmlButton.Enabled = true;
                    }
                }
                else
                    StatusLabel.Text = "Upload status: Only PDF files are accepted!";
            }
            catch (Exception ex)
            {
                StatusLabel.Text = "Upload status: The file could not be uploaded. The following error occurred: " + ex.Message;
            }
            
        }

        protected void xmlButton_Click(object sender, EventArgs e)
        {
            resultBox.Visible = true;
            string response = PostXML(SERVER_PATH, "inputXML=" + Server.UrlEncode(xmlTextInput.Text));
            response = Regex.Replace(response, "(?si)<!DOCTYPE.*", "");
            result.InnerHtml = "<xmp>" + response.Trim() + "</xmp>";
            string returnCode = Regex.Match(response, @"(?si)<returnCode>([^<>]*)</returnCode>").Groups[1].Value;
            string sessionID = Regex.Match(response, @"(?si)<sessionId>([^<>]*)</sessionId>").Groups[1].Value;

            // If a session ID has returned in the response, call the UploadDoc.aspx with the sessionID parameter as below
            if (returnCode == SUCCESS && !string.IsNullOrEmpty(sessionID))
            {
                wscIFrame.Attributes["src"] = SERVER_PATH + "?sessionId=" + sessionID;
                xmlButton.Enabled = false;
                Session.Remove("id");
            }
        }

        private string getXmlFileName(RadioButton radioButton)
        {
            if (radioButton.ID == "RadioButton1")
                return "example1";
            else if (radioButton.ID == "RadioButton2")
                return "example2";

            return "example3";
        }

        private void CopyStream(Stream input, Stream output)
        {
            byte[] buffer = new byte[8 * 1024];
            int len;
            while ((len = input.Read(buffer, 0, buffer.Length)) > 0)
            {
                output.Write(buffer, 0, len);
            }
        }

        protected void fileUploadControl_DataBinding(object sender, EventArgs e)
        {
            labelChosenFile.Text = fileUploadControl.FileName;
        }
    }
}
