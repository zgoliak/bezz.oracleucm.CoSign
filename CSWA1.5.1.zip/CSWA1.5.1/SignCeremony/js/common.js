﻿function handleSessionTimeout()
{
    setTimeout('redirectToLoginPage()',(parseInt(sessionTimeout) * 60 * 1000) - 10000);
}

function redirectToLoginPage(finishURL)
{
    if (sessionId == null) sessionId = "";
    window.location.href = "Login.aspx?sessionId=" + sessionId;
}