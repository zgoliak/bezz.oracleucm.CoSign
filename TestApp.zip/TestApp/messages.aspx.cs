﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Xml;

namespace testApp
{
    public partial class messages : System.Web.UI.Page
    {
        string username;

        // Parameters recievied upon 'Password Change' message:
        // id, username, passChanged ('true' for success)
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Request["passChanged"]))
            {
                if (Request["passChanged"] == "true")
                {
                    if (!string.IsNullOrEmpty(Request["username"]))
                    {
                        username = Request["username"];
                    }
                }
            }
            else if (!string.IsNullOrEmpty(Request["sigDetails"]))
            {
                using (StreamWriter outfile = new StreamWriter(Server.MapPath("~/sigDetails.txt"), true))
                {
                    outfile.Write(Server.UrlDecode((Request["sigDetails"])) + Environment.NewLine);
                }
            }
        }

        protected void buttonTest_Click(object sender, EventArgs e)
        {
            string response = sendRequest("http://localhost:54015/pullSignedDoc.ashx" + "?sessionId=" + TextBoxSession.Text);
            //string response = sendRequest("http://212.25.124.10/WSCtest/pullSignedDoc.ashx" + "?sessionId=" + TextBoxSession.Text);

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(response);
            labelTest.Text = "returnCode=" + doc.DocumentElement.GetElementsByTagName("returnCode")[0].InnerText;

            if (doc.DocumentElement.GetElementsByTagName("errorMessage").Count > 0)
            {
                labelTest.Text += ", errorMessage= " + doc.DocumentElement.GetElementsByTagName("errorMessage")[0].InnerText;
            }

            if (doc.DocumentElement.GetElementsByTagName("Document").Count > 0)
            {
                string base64EncodedFile = doc.DocumentElement.GetElementsByTagName("content")[0].InnerText;
                string contentType = doc.DocumentElement.GetElementsByTagName("contentType")[0].InnerText;
                File.WriteAllBytes(Server.MapPath("~/" + TextBoxSession.Text + "." + contentType), Convert.FromBase64String(base64EncodedFile));
            }
        }

        private string sendRequest(string i_Url)
        {
            string data = null;
            HttpWebRequest WebReq = (HttpWebRequest)WebRequest.Create(i_Url);
            WebReq.Method = "GET";
            HttpWebResponse WebResp = (HttpWebResponse)WebReq.GetResponse();
            Stream Answer = WebResp.GetResponseStream();
            StreamReader _Answer = new StreamReader(Answer);
            data = _Answer.ReadToEnd();
            _Answer.Close();
            WebResp.Close();
            return data;
        }
    }
}
